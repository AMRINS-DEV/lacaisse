export default function UnauthorizedPage() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-destructive">Accès refusé</h1>
        <p className="text-muted-foreground mt-2">Vous n&apos;avez pas les droits nécessaires.</p>
      </div>
    </div>
  );
}
