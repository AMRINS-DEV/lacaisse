import { RootLoadingScreen } from "@/components/loading/AppLoadingShells";

export default function Loading() {
  return <RootLoadingScreen />;
}
