import { NextResponse } from "next/server";
import { query } from "@/lib/db";
import { normalizeServiceKey, SERVICE_COOKIE_NAME } from "@/lib/service-context";

type TransactionRow = {
  id: number;
  type: "income" | "expense";
  description: string;
  amount: number;
  category: string;
  location_name: string;
  date: string;
};

type CategoryRow = {
  id: number;
  name: string;
  type: "income" | "expense";
};

type LocationRow = {
  id: number;
  name: string;
  code: string | null;
};

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const q = (searchParams.get("q") ?? "").trim();
  const cookieHeader = request.headers.get("cookie") ?? "";
  const activeServiceCookie = cookieHeader
    .split(";")
    .map((value) => value.trim())
    .find((value) => value.startsWith(`${SERVICE_COOKIE_NAME}=`))
    ?.split("=")
    .slice(1)
    .join("=");
  const serviceKey = normalizeServiceKey(activeServiceCookie);

  if (q.length < 2) {
    return NextResponse.json({
      query: q,
      groups: {
        recettes: [],
        charges: [],
        categories: [],
        locations: [],
      },
    });
  }

  const like = `%${q}%`;

  const [transactions, categories, locations] = await Promise.all([
    query<TransactionRow>(
      `SELECT d.id,
              d.type,
              COALESCE(d.description, '') as description,
              d.amount,
              COALESCE(c.name, '') as category,
              COALESCE(l.name, l.code, '') as location_name,
              DATE_FORMAT(d.transaction_date, '%Y-%m-%d') as date
       FROM transactions d
       LEFT JOIN categories c ON c.id = d.category_id
       LEFT JOIN locations l ON l.id = d.location_id
       WHERE d.type IN ('income', 'expense')
         AND d.service_key = ?
         AND (
           d.description LIKE ?
           OR c.name LIKE ?
           OR l.name LIKE ?
           OR l.code LIKE ?
         )
       ORDER BY d.transaction_date DESC, d.id DESC
       LIMIT 14`,
      [serviceKey, like, like, like, like]
    ),
    query<CategoryRow>(
      `SELECT id, name, type
       FROM categories
       WHERE is_active = 1
         AND name LIKE ?
       ORDER BY name ASC
       LIMIT 8`,
      [like]
    ),
    query<LocationRow>(
      `SELECT id, name, code
       FROM locations
       WHERE is_active = 1
         AND (name LIKE ? OR code LIKE ?)
       ORDER BY name ASC
       LIMIT 6`,
      [like, like]
    ),
  ]);

  const recettes = transactions.filter((row) => row.type === "income");
  const charges = transactions.filter((row) => row.type === "expense");

  return NextResponse.json({
    query: q,
    groups: {
      recettes,
      charges,
      categories,
      locations,
    },
  });
}
