import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { queryOne } from "@/lib/db";

type Params = {
  params: Promise<{ id: string }>;
};

function inferMimeType(mimeType: string, originalName: string) {
  const normalizedMime = String(mimeType ?? "").trim().toLowerCase();
  if (normalizedMime && normalizedMime !== "application/octet-stream") {
    return normalizedMime;
  }
  const lowerName = String(originalName ?? "").toLowerCase();
  if (lowerName.endsWith(".pdf")) return "application/pdf";
  if (lowerName.endsWith(".png")) return "image/png";
  if (lowerName.endsWith(".webp")) return "image/webp";
  if (lowerName.endsWith(".gif")) return "image/gif";
  if (lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg")) return "image/jpeg";
  return "application/octet-stream";
}

function extensionFromMime(mimeType: string) {
  const normalized = (mimeType || "").toLowerCase();
  if (normalized === "application/pdf") return ".pdf";
  if (normalized === "image/png") return ".png";
  if (normalized === "image/webp") return ".webp";
  if (normalized === "image/gif") return ".gif";
  if (normalized === "image/jpeg" || normalized === "image/jpg") return ".jpg";
  return "";
}

function ensureFileExtension(fileName: string, mimeType: string) {
  if (/\.[a-z0-9]{2,8}$/i.test(fileName)) return fileName;
  const ext = extensionFromMime(mimeType);
  return ext ? `${fileName}${ext}` : fileName;
}

function toSafeAsciiFileName(name: string) {
  return name.replace(/[^\x20-\x7E]+/g, "_").replace(/"/g, "_");
}

function detectMimeFromBytes(bytes: Buffer): string | null {
  if (bytes.length < 4) return null;
  if (bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46) return "application/pdf";
  if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return "image/png";
  if (bytes[0] === 0xff && bytes[1] === 0xd8) return "image/jpeg";
  if (bytes[0] === 0x47 && bytes[1] === 0x49 && bytes[2] === 0x46) return "image/gif";
  if (bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46) return "image/webp";
  return null;
}

function tryReadLocalFile(fileName: string): Buffer | null {
  const localPath = join(process.cwd(), "public", "uploads", "recettes", fileName);
  if (existsSync(localPath)) {
    return readFileSync(localPath);
  }
  return null;
}

export async function GET(_request: Request, { params }: Params) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Non authentifie" }, { status: 401 });
  }

  const { id } = await params;
  const attachmentId = Number.parseInt(id, 10);
  if (!Number.isFinite(attachmentId) || attachmentId <= 0) {
    return NextResponse.json({ error: "ID invalide" }, { status: 400 });
  }

  const attachment = await queryOne<{
    id: number;
    original_name: string;
    mime_type: string;
    path: string;
  }>(
    "SELECT id, original_name, mime_type, path FROM attachments WHERE id = ? LIMIT 1",
    [attachmentId]
  );

  if (!attachment) {
    return NextResponse.json({ error: "Fichier introuvable" }, { status: 404 });
  }

  const url = new URL(_request.url);
  const shouldDownload = url.searchParams.get("download") === "1";
  const storedNameFromPath =
    attachment.path.split("/").pop()?.split("?")[0] || attachment.original_name || "file";
  const effectiveMimeType = inferMimeType(attachment.mime_type, attachment.original_name);
  const downloadName = ensureFileExtension(storedNameFromPath, effectiveMimeType);
  const asciiName = toSafeAsciiFileName(downloadName);
  const encodedName = encodeURIComponent(downloadName);
  const dispositionType = shouldDownload ? "attachment" : "inline";

  const responseHeaders = {
    "Content-Disposition": `${dispositionType}; filename="${asciiName}"; filename*=UTF-8''${encodedName}`,
    "Cache-Control": "private, max-age=3600",
    "X-Content-Type-Options": "nosniff",
  };

  const localBytes = storedNameFromPath ? tryReadLocalFile(storedNameFromPath) : null;
  if (localBytes) {
    const detectedMime = detectMimeFromBytes(localBytes);
    const localContentType =
      effectiveMimeType !== "application/octet-stream"
        ? effectiveMimeType
        : (detectedMime ?? effectiveMimeType);
    return new NextResponse(new Uint8Array(localBytes), {
      status: 200,
      headers: { "Content-Type": localContentType, ...responseHeaders },
    });
  }

  return NextResponse.json({ error: "Impossible de lire le fichier" }, { status: 404 });
}
