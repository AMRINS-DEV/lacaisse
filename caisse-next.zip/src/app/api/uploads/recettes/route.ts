import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { storeAttachmentFileLocally, validateAttachmentFile } from "@/lib/storage/attachments";
const ALLOWED_ROLES = new Set(["admin", "manager", "location_user"]);

export async function POST(request: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Non authentifie" }, { status: 401 });
  }

  const role = String((session.user as { role?: string }).role ?? "");
  if (!ALLOWED_ROLES.has(role)) {
    return NextResponse.json({ error: "Acces refuse" }, { status: 403 });
  }

  const userIdRaw = (session.user as { id?: string }).id;
  const userId = Number.parseInt(String(userIdRaw ?? ""), 10);
  if (!Number.isFinite(userId) || userId <= 0) {
    return NextResponse.json({ error: "Utilisateur invalide" }, { status: 400 });
  }

  const formData = await request.formData();
  const fileEntry = formData.get("file");
  if (!(fileEntry instanceof File)) {
    return NextResponse.json({ error: "Aucun fichier fourni" }, { status: 400 });
  }

  if (!fileEntry.name || fileEntry.size <= 0) {
    return NextResponse.json({ error: "Fichier vide" }, { status: 400 });
  }

  const validationError = validateAttachmentFile(fileEntry);
  if (validationError) {
    return NextResponse.json({ error: validationError }, { status: 400 });
  }

  try {
    const attachment = await storeAttachmentFileLocally(fileEntry, userId);
    return NextResponse.json(attachment);
  } catch {
    return NextResponse.json(
      { error: "Impossible d'enregistrer le fichier pour le moment." },
      { status: 500 }
    );
  }
}
