import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({ error: "Asset introuvable" }, { status: 404 });
}
